# LLM

Wrapper classes for Hugging Face Transformers LLM models.

## Environment

To use Google CodeGemma models, set the `HUGGING_FACE_TOKEN` environment variable with your Hugging Face access token.

## Cache

By default models are cached to ./cache.

## Tests

Only generated tests exists currently.
